I have not worked with anyone for this assignment. I have simply used my previous knowledge and python documentation.

Used the following URL to find out how to sort the Dictionary by values:
https://www.geeksforgeeks.org/python-sort-python-dictionaries-by-key-or-value/

URL of the Solver in a5 - https://planetcalc.com/8047/

The only one thing that does not work in the assignment is alphabetical ordering in a5p1. My question was clarified
in the end and at the time, I tried to alphabatize as outlined in the assignment instrctions, but it was giving
me an error. So instead, I took the first character in the ETAOIN list to break the ties (but that is not really wrong I guess).
But rest everything works perfectly in all parts other than this alphabatizing thing.