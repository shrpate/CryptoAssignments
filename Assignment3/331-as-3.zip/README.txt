I, Shridhar Patel, have not collaborated with any person in this course or outside this course.
I soley used my previous Python knowledge, Math 222 (cryptography) content and Math 228 (Ring Theory) content.
I have not consulted to any websites either.
For Q4, I used all the expressions and equations from Q3 (everything to be commented to make sense).