The following URL was used for finding the list of Prime Numbers.
https://www.programiz.com/python-programming/examples/prime-number-intervals

Module(s) used from textbook:
- publicKeyCipher.py


I have soley worked by myself on this assignment and have no consulted anyone in this class or outside this class.

Other then the link above, I have used no other URL, videos, modules etc
