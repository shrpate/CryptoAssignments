Following sources are used for for Q1

https://stackoverflow.com/questions/39921087/a-openfile-r-a-readline-output-without-n  (TO PROPERLY READ THE FILE)
https://www.geeksforgeeks.org/permutation-and-combination-in-python/    (FOR PERMUTATIONS IMPORT)

For Q2 I used Python Offical documentation especially to look up the rules of dictionary.

For Q3, I used the REGEX videos from eclass page and Python Documentation for REGEX.