I have no collaborated with anyone for this assignment. It is simply my effors put together with course material.

Few Notes:
        All Tests pass in the provided test file "provided_tests.v4.py"
        Test 1 and Test 2 takes 2 seconds (quite fast) and Test 3 takes 2 minutes to run but it 100% works.

        In problem 1, I am using the info at the following link to join the ngrams:
                https://www.geeksforgeeks.org/python-merge-list-elements/
        This slows down the process by a little bit but still unnoticable in Q1 and Q2
        
        This issue is mutipled by 325 (the for loop) in Q3. Therefore it technically becomes about 300 times slower.
        This issue is carried in Q4 and also caused it to be slower.

        If they are tested independently, Q3 and Q4 should be fast enough but they slow down because of initial
        issue that slows down Q1.

        From what I read, efficiency does not matter too too much for this assignment as long as the functions
        are working.