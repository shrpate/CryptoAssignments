I have not collaborated with anyone in this class or anyone outside this class.
I have simply used my previous python knowledge and Math 222 knowledge (cryptography).

All the problems work 100%.
a7p1 recursively solves the problem. It encrypts the text after the dash each time, 
finds the ngrams of the encrypted and repeats. At the end, the final List is join with
a random letter.

a7p2,a7p3 and a7p4 explanation is in the comments.

Thank you for reading this.